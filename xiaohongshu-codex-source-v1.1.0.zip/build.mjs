import { readFile, writeFile } from 'node:fs/promises';
const css = await readFile(new URL('./src/style.css', import.meta.url), 'utf8');
const app = await readFile(new URL('./src/app.js', import.meta.url), 'utf8');
const workflow = await readFile(new URL('./src/workflow.js', import.meta.url), 'utf8');
const files = { 'workflow.js': workflow, 'app.js': app, 'style.css': css };
const license = await readFile(new URL('./reference/LICENSE', import.meta.url), 'utf8');
const meta = `// ==UserScript==
// @name         小红书 · Codex 桌面外观
// @namespace    xhs-codex-local
// @homepageURL  https://github.com/troyluce/xiaohongshu-codex-userscript
// @supportURL   https://github.com/troyluce/xiaohongshu-codex-userscript/issues
// @downloadURL  https://raw.githubusercontent.com/troyluce/xiaohongshu-codex-userscript/main/xiaohongshu-codex.user.js
// @updateURL    https://raw.githubusercontent.com/troyluce/xiaohongshu-codex-userscript/main/xiaohongshu-codex.user.js
// @version      1.1.0
// @description  将小红书网页版换成 Codex 桌面风格，智能体流程与源码双栏、行号和语法高亮，默认隐藏媒体，支持深浅主题及 Alt+Q 遮挡。
// @author       Troy, with Codex; inspired by czm15053
// @license      MIT
// @match        https://www.xiaohongshu.com/*
// @match        https://xiaohongshu.com/*
// @run-at       document-start
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_setClipboard
// @noframes
// ==/UserScript==

/*
Reference: https://github.com/czm15053/linuxdo-idea-ui
Adapted palette and host selectors from linuxdo-codex.user.js and xhs/src.
${license.trim()}
*/

`;
await writeFile(new URL('./xiaohongshu-codex.user.js', import.meta.url), meta+app.replace('__XC_WORKFLOW__',()=>`(${workflow})()`).replace('__XC_SOURCE_FILES__',()=>JSON.stringify(files)).replace('__XC_CSS__',()=>JSON.stringify(css)));
console.log('Built xiaohongshu-codex.user.js');
