import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM, VirtualConsole } from 'jsdom';
const code=await readFile('xiaohongshu-codex.user.js','utf8');
const capture=JSON.parse(await readFile('reference/dom-capture.json','utf8'));
const delay=()=>new Promise(r=>setTimeout(r,140));
async function setup(t,{prefs={},path='/explore',htmlContent=capture.global,isNarrow=false}={}) {
  const dom=new JSDOM(`<!doctype html><head><title>原始小红书</title><link rel="icon" href="/original.ico"></head><body><div id="app">${htmlContent}</div></body>`,{url:'https://www.xiaohongshu.com'+path,runScripts:'outside-only',virtualConsole:new VirtualConsole()});
  const w=dom.window,d=w.document,stored=[];
  const events=new Map();
  w.matchMedia=q=>({matches:q.includes("max-width")?isNarrow:false,media:q,addEventListener:(_,cb)=>events.set(q,cb)});
  w.GM_getValue=()=>prefs;w.GM_setValue=(k,v)=>stored.push(structuredClone(v));w.GM_registerMenuCommand=()=>{};
  w.scrollTo=()=>{};
  let pauses=0;w.HTMLMediaElement.prototype.pause=function(){pauses++};
  const input=d.querySelector('#search-input'),originalPlaceholder=input.getAttribute('placeholder');
  const native=d.querySelector('.note-item a.title');
  w.eval(code);await delay();
  t.after(()=>dom.window.close());
  const click=id=>d.querySelector(id).click();
  const key=(keyCode,target=d.body,options={})=>target.dispatchEvent(new w.KeyboardEvent('keydown',{code:keyCode,altKey:true,bubbles:true,cancelable:true,...options}));
  const detail=()=>{const host=d.createElement('div');host.innerHTML=capture.detail;const n=host.firstElementChild;d.querySelector('#app').append(n);return n;};
  return {w,d,stored,events,click,key,detail,input,originalPlaceholder,native,pauses:()=>pauses};
}
test('keeps native card nodes and listeners; mounts one shell and intro',async t=>{
 const s=await setup(t);let calls=0;s.native.addEventListener('click',e=>{e.preventDefault();calls++});s.native.click();await delay();
 assert.equal(calls,1);assert.equal(s.d.querySelector('.note-item a.title'),s.native);assert.equal(s.d.querySelectorAll('#xc-shell').length,1);assert.equal(s.d.querySelectorAll('.xc-intro').length,1);
 assert.equal(s.w.getComputedStyle(s.d.querySelector('.note-item .cover')).display,'none');
});
test('detail media starts hidden and resets when native note is replaced',async t=>{
 const s=await setup(t);let n=s.detail();await delay();assert.equal(s.d.documentElement.dataset.xcMedia,'hide');assert.equal(s.d.querySelector('#xc-media').hidden,false);
 s.click('#xc-media');assert.equal(s.d.documentElement.dataset.xcMedia,'show');s.click('#xc-original');s.click('#xc-restore');await delay();assert.equal(s.d.documentElement.dataset.xcMedia,'hide');assert.equal(s.d.querySelector('#xc-media').getAttribute('aria-pressed'),'false');assert.equal(s.d.querySelector('#noteContainer .xc-agent-flow')!==null,true);n.remove();n=s.detail();await delay();assert.equal(s.d.documentElement.dataset.xcMedia,'hide');
 n.remove();await delay();assert.equal(s.d.querySelector('#xc-media').hidden,true);
});
test('panic blocks native focus and pauses audio; recovery restores focus',async t=>{
 const s=await setup(t);const video=s.d.createElement('video');Object.defineProperty(video,'paused',{value:false});s.d.querySelector('#app').append(video);s.input.focus();s.key('KeyQ',s.input);
 assert.equal(s.d.documentElement.dataset.xcPanic,'true');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);assert.ok(s.pauses()>0);
 s.key('KeyQ');assert.equal(s.d.documentElement.dataset.xcPanic,'false');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);assert.equal(s.d.activeElement,s.input);
});
test('disabling from panic restores title, favicon, input and native interaction',async t=>{
 const s=await setup(t);s.key('KeyQ');s.click('#xc-original');await delay();
 assert.equal(s.d.documentElement.dataset.xcEnabled,'false');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);assert.equal(s.d.title,'原始小红书');assert.equal(s.d.querySelector('link[rel=icon]').getAttribute('href'),'/original.ico');assert.equal(s.input.getAttribute('placeholder'),s.originalPlaceholder);assert.equal(s.d.querySelector('.xc-intro'),null);
 s.click('#xc-restore');await delay();assert.equal(s.d.querySelector('#xc-panic-toggle').getAttribute('aria-pressed'),'false');assert.equal(s.d.querySelectorAll('.xc-intro').length,1);
});
test('preserves an existing inert attribute on the host',async t=>{
 const s=await setup(t);s.d.querySelector('#app').setAttribute('inert','');s.key('KeyQ');s.key('KeyQ');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);
});
test('keyboard ignores typing and IME for appearance toggle; panic remains global',async t=>{
 const s=await setup(t);s.key('KeyX',s.input);assert.equal(s.d.documentElement.dataset.xcEnabled,'true');s.key('KeyQ',s.input,{isComposing:true});assert.equal(s.d.documentElement.dataset.xcPanic,undefined);s.key('KeyX');assert.equal(s.d.documentElement.dataset.xcEnabled,'false');
});
test('disabled preference keeps original branding and input untouched on reload',async t=>{
 const s=await setup(t,{prefs:{enabled:false}});assert.equal(s.d.title,'原始小红书');assert.equal(s.input.getAttribute('placeholder'),s.originalPlaceholder);assert.equal(s.d.querySelector('.xc-intro'),null);
});
test('unsupported routes stay native, then activate on supported SPA navigation',async t=>{
 const s=await setup(t,{path:'/notification'});assert.equal(s.d.documentElement.dataset.xcEnabled,'false');s.w.history.pushState({},'','/explore');s.w.dispatchEvent(new s.w.PopStateEvent('popstate'));await delay();assert.equal(s.d.documentElement.dataset.xcEnabled,'true');
});
test('recent entries use text nodes and reject links outside the site',async t=>{
 const s=await setup(t);s.native.textContent='<img src=x onerror=alert(1)>';s.d.querySelectorAll('.note-item a.title')[1].href='javascript:alert(1)';s.d.querySelectorAll('.note-item a.title')[2].href='https://evil.example/explore/a';await delay();
 const recent=s.d.querySelector('#xc-recent');assert.equal(recent.querySelector('img'),null);assert.ok(recent.textContent.includes('<img'));assert.equal(recent.querySelectorAll('a').length,3);
});
test('dynamic feed updates and title changes keep shell unique and update the count',async t=>{
 const s=await setup(t);const feed=s.d.querySelector('.feeds-container');const original=feed.querySelectorAll(".note-item").length;
 for(let i=0;i<20;i++)feed.append(feed.firstElementChild.cloneNode(true));s.d.title='新页面 - 小红书';await delay();assert.ok(s.d.querySelector('#xc-count').textContent.includes(String(original+20)));assert.equal(s.d.title,'Codex');assert.equal(s.d.querySelectorAll('#xc-shell').length,1);
});
test('empty feed can populate later without remounting',async t=>{
 const s=await setup(t);const feed=s.d.querySelector('.feeds-container');const card=feed.firstElementChild;feed.replaceChildren();await delay();assert.equal(s.d.querySelectorAll('#xc-recent a').length,0);feed.append(card);await delay();assert.equal(s.d.querySelectorAll('#xc-recent a').length,1);
});
test('recent entries delegate normal clicks to native handlers, preserve modified clicks',async t=>{
 const s=await setup(t);let calls=0;s.native.addEventListener('click',e=>{e.preventDefault();calls++});const a=s.d.querySelector('#xc-recent a');a.click();assert.equal(calls,1);
 const event=new s.w.MouseEvent('click',{bubbles:true,cancelable:true,ctrlKey:true});a.dispatchEvent(event);assert.equal(event.defaultPrevented,false);assert.equal(calls,1);
});
test('theme changes are persisted and system theme remains reactive',async t=>{
 const s=await setup(t);s.click('#xc-theme');assert.equal(s.d.documentElement.dataset.xcTheme,'light');assert.equal(s.stored.at(-1).theme,'light');s.click('#xc-theme');assert.equal(s.d.documentElement.dataset.xcTheme,'dark');
});
test('hidden videos cannot start playback until detail media is explicitly shown',async t=>{
 const s=await setup(t);s.detail();await delay();const video=s.d.createElement('video');s.d.querySelector('#noteContainer .media-container').append(video);const n=s.pauses();video.dispatchEvent(new s.w.Event('play',{bubbles:false}));assert.equal(s.pauses(),n+1);s.click('#xc-media');video.dispatchEvent(new s.w.Event('play',{bubbles:false}));assert.equal(s.pauses(),n+1);
});

test('native feed scroll listener stays attached and search returns to its top',async t=>{
 const s=await setup(t);const feed=s.d.querySelector('.feeds-page');let calls=0;feed.addEventListener('scroll',()=>calls++);feed.scrollTop=420;feed.dispatchEvent(new s.w.Event('scroll'));assert.equal(calls,1);assert.equal(s.d.documentElement.style.getPropertyValue('--xc-feed-scroll'),'420px');s.click('#xc-focus-search');assert.equal(feed.scrollTop,0);assert.equal(s.d.activeElement,s.input);
});
test('current search DOM retains the native query and receives the same skin',async t=>{
 const search=JSON.parse(await readFile('reference/search-dom-capture.json','utf8'));const s=await setup(t,{path:'/search_result?keyword=codex',htmlContent:search.global});assert.equal(s.input.value,'codex');assert.ok(s.d.querySelectorAll('#xc-recent a').length>0);assert.equal(s.d.querySelector('#xc-crumb').textContent,'搜索结果');assert.equal(s.d.querySelectorAll('.xc-intro').length,1);assert.equal(s.d.documentElement.dataset.xcEnabled,'true');
});

test('narrow sidebar closes before focusing the native search field',async t=>{
 const s=await setup(t,{isNarrow:true});s.click('#xc-sidebar-toggle');assert.equal(s.d.documentElement.dataset.xcCollapsed,'false');s.click('#xc-focus-search');assert.equal(s.d.documentElement.dataset.xcCollapsed,'true');assert.equal(s.d.activeElement,s.input);
});
test('narrow profile action closes sidebar and delegates to native profile link',async t=>{
 const search=JSON.parse(await readFile('reference/search-dom-capture.json','utf8'));const s=await setup(t,{isNarrow:true,htmlContent:search.global});let called=false;s.d.querySelector('#global .side-bar a[href^="/user/profile/"]').addEventListener('click',e=>{e.preventDefault();called=true});s.click('#xc-sidebar-toggle');s.click('#xc-profile');assert.equal(called,true);assert.equal(s.d.documentElement.dataset.xcCollapsed,'true');
});

test('source panel displays the exact project source without creating source HTML',async t=>{
 const s=await setup(t);const original=await readFile('src/workflow.js','utf8');const shown=[...s.d.querySelectorAll('.xc-line-code')].map(n=>n.textContent).join('\n');assert.equal(shown,original);assert.equal(s.d.querySelectorAll('#xc-code-body script,#xc-code-body svg').length,0);
 s.click('[data-xc-file="app.js"]');const app=await readFile('src/app.js','utf8');assert.equal([...s.d.querySelectorAll('.xc-line-code')].map(n=>n.textContent).join('\n'),app);assert.equal(s.d.querySelectorAll('#xc-code-body svg').length,0);
});
test('source file tabs support arrow navigation and code wrapping',async t=>{
 const s=await setup(t);const tab=s.d.querySelector('[data-xc-file="workflow.js"]');tab.focus();tab.dispatchEvent(new s.w.KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true,cancelable:true}));assert.equal(s.d.activeElement.dataset.xcFile,'app.js');assert.equal(s.d.querySelector('#xc-code-file').textContent,'app.js');s.click('#xc-code-wrap');assert.equal(s.d.querySelector('#xc-code-wrap').getAttribute('aria-pressed'),'true');assert.equal(s.d.querySelector('#xc-code-body').classList.contains('xc-code-wrapped'),true);
});
test('desktop source visibility is saved and never blocks the native page',async t=>{
 const s=await setup(t);assert.equal(s.d.documentElement.dataset.xcEditor,'true');s.click('#xc-editor-close');assert.equal(s.d.documentElement.dataset.xcEditor,'false');assert.equal(s.stored.at(-1).code,false);assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);s.click('#xc-code-toggle');assert.equal(s.d.documentElement.dataset.xcEditor,'true');
});
test('mobile source overlay and panic share inert state and restore native focus',async t=>{
 const s=await setup(t,{isNarrow:true});assert.equal(s.d.documentElement.dataset.xcEditor,'false');s.click('#xc-code-toggle');assert.equal(s.d.documentElement.dataset.xcEditorOverlay,'true');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);assert.equal(s.d.activeElement.id,'xc-code-body');s.key('KeyQ');s.click('#xc-editor-close');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);s.key('KeyQ');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);s.click('#xc-code-toggle');s.click('#xc-original');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);
});
test('workflow decorations remain unique after cloned cards and are removed in native mode',async t=>{
 const s=await setup(t);const card=s.d.querySelector('.note-item');card.parentElement.append(card.cloneNode(true));await delay();for(const n of s.d.querySelectorAll('.note-item'))assert.equal(n.querySelectorAll('.xc-agent-step').length,1);s.click('#xc-original');assert.equal(s.d.querySelectorAll('.xc-agent-step,.xc-agent-flow').length,0);s.click('#xc-restore');await delay();for(const n of s.d.querySelectorAll('.note-item'))assert.equal(n.querySelectorAll('.xc-agent-step').length,1);
});
test('copy source uses the currently selected real file',async t=>{
 const s=await setup(t);let copied='';Object.defineProperty(s.w.navigator,'clipboard',{value:{writeText:async value=>{copied=value}}});s.click('[data-xc-file="style.css"]');s.click('#xc-code-copy');await Promise.resolve();assert.equal(copied,await readFile('src/style.css','utf8'));assert.equal(s.d.querySelector('#xc-copy-status').textContent,'已复制');
});
