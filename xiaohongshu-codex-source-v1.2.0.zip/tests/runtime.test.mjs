import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM, VirtualConsole } from 'jsdom';
const code=await readFile('xiaohongshu-codex.user.js','utf8');
const capture=JSON.parse(await readFile('reference/dom-capture.json','utf8'));
const delay=()=>new Promise(r=>setTimeout(r,140));
async function setup(t,{prefs={},path='/explore',htmlContent=capture.global,isNarrow=false}={}) {
  const dom=new JSDOM(`<!doctype html><head><title>原始小红书</title><link rel="icon" href="/original.ico"></head><body><div id="app">${htmlContent}</div></body>`,{url:'https://www.xiaohongshu.com'+path,runScripts:'outside-only',virtualConsole:new VirtualConsole()});
  const w=dom.window,d=w.document,stored=[];
  const events=new Map();
  w.matchMedia=q=>({matches:q.includes("max-width")?isNarrow:false,media:q,addEventListener:(_,cb)=>events.set(q,cb)});
  w.GM_getValue=()=>prefs;w.GM_setValue=(k,v)=>stored.push(structuredClone(v));w.GM_registerMenuCommand=()=>{};
  w.scrollTo=()=>{};
  let pauses=0;w.HTMLMediaElement.prototype.pause=function(){pauses++};
  const input=d.querySelector('#search-input'),originalPlaceholder=input.getAttribute('placeholder');
  const native=d.querySelector('.note-item a.title');
  w.eval(code);await delay();
  t.after(()=>dom.window.close());
  const click=id=>d.querySelector(id).click();
  const key=(keyCode,target=d.body,options={})=>target.dispatchEvent(new w.KeyboardEvent('keydown',{code:keyCode,altKey:true,bubbles:true,cancelable:true,...options}));
  const detail=()=>{const host=d.createElement('div');host.innerHTML=capture.detail;const n=host.firstElementChild;d.querySelector('#app').append(n);return n;};
  return {w,d,stored,events,click,key,detail,input,originalPlaceholder,native,pauses:()=>pauses};
}
test('keeps native card nodes and listeners; mounts one shell and intro',async t=>{
 const s=await setup(t);let calls=0;s.native.addEventListener('click',e=>{e.preventDefault();calls++});s.native.click();await delay();
 assert.equal(calls,1);assert.equal(s.d.querySelector('.note-item a.title'),s.native);assert.equal(s.d.querySelectorAll('#xc-shell').length,1);assert.equal(s.d.querySelectorAll('.xc-intro').length,1);
 assert.equal(s.w.getComputedStyle(s.d.querySelector('.note-item .cover')).display,'none');
});
test('detail media starts hidden and resets when native note is replaced',async t=>{
 const s=await setup(t);let n=s.detail();await delay();assert.equal(s.d.documentElement.dataset.xcMedia,'hide');assert.equal(s.d.querySelector('#xc-media').hidden,false);
 s.click('#xc-media');assert.equal(s.d.documentElement.dataset.xcMedia,'show');s.click('#xc-original');s.click('#xc-restore');await delay();assert.equal(s.d.documentElement.dataset.xcMedia,'hide');assert.equal(s.d.querySelector('#xc-media').getAttribute('aria-pressed'),'false');assert.equal(s.d.querySelector('#noteContainer .xc-agent-flow')!==null,true);n.remove();n=s.detail();await delay();assert.equal(s.d.documentElement.dataset.xcMedia,'hide');
 n.remove();await delay();assert.equal(s.d.querySelector('#xc-media').hidden,true);
});
test('panic blocks native focus and pauses audio; recovery restores focus',async t=>{
 const s=await setup(t);const video=s.d.createElement('video');Object.defineProperty(video,'paused',{value:false});s.d.querySelector('#app').append(video);s.input.focus();s.key('KeyQ',s.input);
 assert.equal(s.d.documentElement.dataset.xcPanic,'true');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);assert.ok(s.pauses()>0);
 s.key('KeyQ');assert.equal(s.d.documentElement.dataset.xcPanic,'false');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);assert.equal(s.d.activeElement,s.input);
});
test('disabling from panic restores title, favicon, input and native interaction',async t=>{
 const s=await setup(t);s.key('KeyQ');s.click('#xc-original');await delay();
 assert.equal(s.d.documentElement.dataset.xcEnabled,'false');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);assert.equal(s.d.title,'原始小红书');assert.equal(s.d.querySelector('link[rel=icon]').getAttribute('href'),'/original.ico');assert.equal(s.input.getAttribute('placeholder'),s.originalPlaceholder);assert.equal(s.d.querySelector('.xc-intro'),null);
 s.click('#xc-restore');await delay();assert.equal(s.d.querySelector('#xc-panic-toggle').getAttribute('aria-pressed'),'false');assert.equal(s.d.querySelectorAll('.xc-intro').length,1);
});
test('preserves an existing inert attribute on the host',async t=>{
 const s=await setup(t);s.d.querySelector('#app').setAttribute('inert','');s.key('KeyQ');s.key('KeyQ');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);
});
test('keyboard ignores typing and IME for appearance toggle; panic remains global',async t=>{
 const s=await setup(t);s.key('KeyX',s.input);assert.equal(s.d.documentElement.dataset.xcEnabled,'true');s.key('KeyQ',s.input,{isComposing:true});assert.equal(s.d.documentElement.dataset.xcPanic,undefined);s.key('KeyX');assert.equal(s.d.documentElement.dataset.xcEnabled,'false');
});
test('disabled preference keeps original branding and input untouched on reload',async t=>{
 const s=await setup(t,{prefs:{enabled:false}});assert.equal(s.d.title,'原始小红书');assert.equal(s.input.getAttribute('placeholder'),s.originalPlaceholder);assert.equal(s.d.querySelector('.xc-intro'),null);
});
test('unsupported routes stay native, then activate on supported SPA navigation',async t=>{
 const s=await setup(t,{path:'/notification'});assert.equal(s.d.documentElement.dataset.xcEnabled,'false');s.w.history.pushState({},'','/explore');s.w.dispatchEvent(new s.w.PopStateEvent('popstate'));await delay();assert.equal(s.d.documentElement.dataset.xcEnabled,'true');
});
test('recent entries use text nodes and reject links outside the site',async t=>{
 const s=await setup(t);s.native.textContent='<img src=x onerror=alert(1)>';s.d.querySelectorAll('.note-item a.title')[1].href='javascript:alert(1)';s.d.querySelectorAll('.note-item a.title')[2].href='https://evil.example/explore/a';await delay();
 const recent=s.d.querySelector('#xc-recent');assert.equal(recent.querySelector('img'),null);assert.equal(recent.textContent.includes('<img'),false);assert.equal(recent.querySelectorAll('a').length,5);assert.equal(recent.querySelector('a[href^="javascript:"]'),null);assert.equal(recent.querySelector('a[href^="https://evil.example"]'),null);
});
test('dynamic feed updates and title changes keep shell unique and update the count',async t=>{
 const s=await setup(t);const feed=s.d.querySelector('.feeds-container');const original=feed.querySelectorAll(".note-item").length;
 for(let i=0;i<20;i++)feed.append(feed.firstElementChild.cloneNode(true));s.d.title='新页面 - 小红书';await delay();assert.ok(s.d.querySelector('#xc-count').textContent.includes(String(original+20)));assert.equal(s.d.title,'Codex');assert.equal(s.d.querySelectorAll('#xc-shell').length,1);
});
test('empty feed can populate later without remounting',async t=>{
 const s=await setup(t);const feed=s.d.querySelector('.feeds-container');const card=feed.firstElementChild;feed.replaceChildren();await delay();assert.equal(s.d.querySelectorAll('#xc-recent a').length,5);feed.append(card);await delay();assert.equal(s.d.querySelectorAll('#xc-recent a').length,5);
});
test('recent entries delegate normal clicks to native handlers, preserve modified clicks',async t=>{
 const s=await setup(t);let calls=0;s.native.addEventListener('click',e=>{e.preventDefault();calls++});const a=s.d.querySelector('#xc-recent a');a.click();assert.equal(calls,1);
 const event=new s.w.MouseEvent('click',{bubbles:true,cancelable:true,ctrlKey:true});a.dispatchEvent(event);assert.equal(event.defaultPrevented,false);assert.equal(calls,1);
});
test('theme changes are persisted and system theme remains reactive',async t=>{
 const s=await setup(t);s.click('#xc-theme');assert.equal(s.d.documentElement.dataset.xcTheme,'light');assert.equal(s.stored.at(-1).theme,'light');s.click('#xc-theme');assert.equal(s.d.documentElement.dataset.xcTheme,'dark');
});
test('hidden videos cannot start playback until detail media is explicitly shown',async t=>{
 const s=await setup(t);s.detail();await delay();const video=s.d.createElement('video');s.d.querySelector('#noteContainer .media-container').append(video);const n=s.pauses();video.dispatchEvent(new s.w.Event('play',{bubbles:false}));assert.equal(s.pauses(),n+1);s.click('#xc-media');video.dispatchEvent(new s.w.Event('play',{bubbles:false}));assert.equal(s.pauses(),n+1);
});

test('native feed scroll listener stays attached and search returns to its top',async t=>{
 const s=await setup(t);const feed=s.d.querySelector('.feeds-page');let calls=0;feed.addEventListener('scroll',()=>calls++);feed.scrollTop=420;feed.dispatchEvent(new s.w.Event('scroll'));assert.equal(calls,1);assert.equal(s.d.documentElement.style.getPropertyValue('--xc-feed-scroll'),'420px');s.click('#xc-focus-search');assert.equal(feed.scrollTop,0);assert.equal(s.d.activeElement,s.input);
});
test('current search DOM retains the native query and receives the same skin',async t=>{
 const search=JSON.parse(await readFile('reference/search-dom-capture.json','utf8'));const s=await setup(t,{path:'/search_result?keyword=codex',htmlContent:search.global});assert.equal(s.input.value,'codex');assert.ok(s.d.querySelectorAll('#xc-recent a').length>0);assert.equal(s.d.querySelector('#xc-crumb').textContent,'搜索结果');assert.equal(s.d.querySelectorAll('.xc-intro').length,1);assert.equal(s.d.documentElement.dataset.xcEnabled,'true');
});

test('narrow sidebar closes before focusing the native search field',async t=>{
 const s=await setup(t,{isNarrow:true});s.click('#xc-sidebar-toggle');assert.equal(s.d.documentElement.dataset.xcCollapsed,'false');s.click('#xc-focus-search');assert.equal(s.d.documentElement.dataset.xcCollapsed,'true');assert.equal(s.d.activeElement,s.input);
});
test('narrow profile action closes sidebar and delegates to native profile link',async t=>{
 const search=JSON.parse(await readFile('reference/search-dom-capture.json','utf8'));const s=await setup(t,{isNarrow:true,htmlContent:search.global});let called=false;s.d.querySelector('#global .side-bar a[href^="/user/profile/"]').addEventListener('click',e=>{e.preventDefault();called=true});s.click('#xc-sidebar-toggle');s.click('#xc-profile');assert.equal(called,true);assert.equal(s.d.documentElement.dataset.xcCollapsed,'true');
});

test('source panel displays the exact project source without creating source HTML',async t=>{
 const s=await setup(t);const original=await readFile('src/workflow.js','utf8');const shown=[...s.d.querySelectorAll('.xc-line-code')].map(n=>n.textContent).join('\n');assert.equal(shown,original);assert.equal(s.d.querySelectorAll('#xc-code-body script,#xc-code-body svg').length,0);
 s.click('[data-xc-file="app.js"]');const app=await readFile('src/app.js','utf8');assert.equal([...s.d.querySelectorAll('.xc-line-code')].map(n=>n.textContent).join('\n'),app);assert.equal(s.d.querySelectorAll('#xc-code-body svg').length,0);
});
test('source file tabs support arrow navigation and code wrapping',async t=>{
 const s=await setup(t);const tab=s.d.querySelector('[data-xc-file="workflow.js"]');tab.focus();tab.dispatchEvent(new s.w.KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true,cancelable:true}));assert.equal(s.d.activeElement.dataset.xcFile,'app.js');assert.equal(s.d.querySelector('#xc-code-file').textContent,'app.js');s.click('#xc-code-wrap');assert.equal(s.d.querySelector('#xc-code-wrap').getAttribute('aria-pressed'),'true');assert.equal(s.d.querySelector('#xc-code-body').classList.contains('xc-code-wrapped'),true);
});
test('desktop source visibility is saved and never blocks the native page',async t=>{
 const s=await setup(t);assert.equal(s.d.documentElement.dataset.xcEditor,'true');s.click('#xc-editor-close');assert.equal(s.d.documentElement.dataset.xcEditor,'false');assert.equal(s.stored.at(-1).code,false);assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);s.click('#xc-code-toggle');assert.equal(s.d.documentElement.dataset.xcEditor,'true');
});
test('mobile source overlay and panic share inert state and restore native focus',async t=>{
 const s=await setup(t,{isNarrow:true});assert.equal(s.d.documentElement.dataset.xcEditor,'false');s.click('#xc-code-toggle');assert.equal(s.d.documentElement.dataset.xcEditorOverlay,'true');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);assert.equal(s.d.activeElement.id,'xc-code-body');s.key('KeyQ');s.click('#xc-editor-close');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),true);s.key('KeyQ');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);s.click('#xc-code-toggle');s.click('#xc-original');assert.equal(s.d.querySelector('#app').hasAttribute('inert'),false);
});
test('workflow decorations remain unique after cloned cards and are removed in native mode',async t=>{
 const s=await setup(t);const card=s.d.querySelector('.note-item');card.parentElement.append(card.cloneNode(true));await delay();for(const n of s.d.querySelectorAll('.note-item'))assert.equal(n.querySelectorAll('.xc-agent-step').length,1);s.click('#xc-original');assert.equal(s.d.querySelectorAll('.xc-agent-step,.xc-agent-flow').length,0);s.click('#xc-restore');await delay();for(const n of s.d.querySelectorAll('.note-item'))assert.equal(n.querySelectorAll('.xc-agent-step').length,1);
});
test('copy source uses the currently selected real file',async t=>{
 const s=await setup(t);let copied='';Object.defineProperty(s.w.navigator,'clipboard',{value:{writeText:async value=>{copied=value}}});s.click('[data-xc-file="style.css"]');s.click('#xc-code-copy');await Promise.resolve();assert.equal(copied,await readFile('src/style.css','utf8'));assert.equal(s.d.querySelector('#xc-copy-status').textContent,'已复制');
});

function addComment(s,{id='comment-example',text='原生评论正文',parent,images=[]}={}) {
 const comment=s.d.createElement('div');comment.className='comment-item';comment.id=id;
 const inner=s.d.createElement('div');inner.className='comment-inner-container';const right=s.d.createElement('div');right.className='right';
 const author=s.d.createElement('div');author.className='author-wrapper';author.textContent='示例作者';
 const content=s.d.createElement('div');content.className='content';content.textContent=text;
 for(const src of images){const img=s.d.createElement('img');img.src=src;content.append(img);}
 right.append(author,content);inner.append(right);comment.append(inner);(parent||s.d.querySelector('#noteContainer .comments-container')).append(comment);
 return {comment,content};
}
test('each native comment receives Worked for, process prose, then the unchanged body',async t=>{
 const s=await setup(t);s.detail();await delay();const {comment,content}=addComment(s);let clicks=0;content.addEventListener('click',()=>clicks++);await delay();
 const process=content.previousElementSibling;assert.equal(process.className,'xc-comment-workflow');assert.match(process.querySelector('summary').textContent,/Worked for \d+s/);assert.equal(process.querySelectorAll('p').length,3);assert.equal(process.open,true);content.click();assert.equal(clicks,1);assert.equal(content.textContent,'原生评论正文');
 process.open=false;assert.equal(content.hidden,false);assert.equal(comment.querySelectorAll('.xc-comment-workflow').length,1);
});
test('late replies get one stable reasoning block and restore without deleting comments',async t=>{
 const s=await setup(t);s.detail();await delay();const first=addComment(s,{id:'reply-late'});await delay();const duration=first.content.previousElementSibling.textContent;s.d.querySelector('#noteContainer').append(s.d.createElement('span'));await delay();assert.equal(first.comment.querySelectorAll('.xc-comment-workflow').length,1);assert.equal(first.content.previousElementSibling.textContent,duration);
 s.click('#xc-original');assert.equal(first.content.isConnected,true);assert.equal(first.comment.querySelector('.xc-comment-workflow'),null);s.click('#xc-restore');await delay();assert.match(first.content.previousElementSibling.textContent,/Worked for/);
});
test('post media is available as thumbnails while the full-media button remains usable',async t=>{
 const s=await setup(t);s.detail();await delay();const media=s.d.querySelector('#noteContainer .media-container');const img=s.d.createElement('img');img.src='https://example.com/post-image.png';media.append(img);await delay();
 const thumbnail=s.d.querySelector('.xc-post-thumbnails .xc-thumbnail img');assert.ok(thumbnail);assert.equal(s.d.querySelector('#xc-media').getAttribute('aria-label'),'查看图片 / 视频');assert.equal(s.d.documentElement.dataset.xcMedia,'hide');s.click('#xc-media');assert.equal(s.d.documentElement.dataset.xcMedia,'show');assert.equal(s.d.querySelector('#xc-media').getAttribute('aria-label'),'收起图片 / 视频');
});
test('multiple inline comment images keep separate thumbnails and restore their original nodes',async t=>{
 const s=await setup(t);s.detail();await delay();const {content}=addComment(s,{images:['https://example.com/a.png','https://example.com/b.png']});await delay();assert.equal(content.querySelectorAll('.xc-inline-thumbnails').length,2);assert.equal(content.querySelectorAll('img[data-xc-thumb-source]').length,2);
 s.d.querySelector('#noteContainer').append(s.d.createElement('span'));await delay();assert.equal(content.querySelectorAll('.xc-inline-thumbnails').length,2);s.click('#xc-original');assert.equal(content.querySelectorAll('img').length,2);assert.equal(content.querySelectorAll('[data-xc-thumb-source]').length,0);
});
test('image hover opens the enlarged preview and mouse leave closes it',async t=>{
 const s=await setup(t);s.detail();await delay();const {content}=addComment(s,{images:['https://example.com/hover.png']});await delay();const button=content.querySelector('.xc-thumbnail');button.dispatchEvent(new s.w.MouseEvent('mouseenter'));
 const popup=s.d.querySelector('#xc-image-preview');assert.equal(popup.hidden,false);assert.equal(popup.querySelector('img').src,'https://example.com/hover.png');button.dispatchEvent(new s.w.MouseEvent('mouseleave'));await delay();assert.equal(popup.hidden,true);
});
test('pinned image previews support Escape and close immediately for panic and source overlay',async t=>{
 const s=await setup(t,{isNarrow:true});s.detail();await delay();const {content}=addComment(s,{images:['https://example.com/pinned.png']});await delay();const button=content.querySelector('.xc-thumbnail');button.click();const popup=s.d.querySelector('#xc-image-preview');assert.equal(popup.hidden,false);s.d.querySelector('.note-scroller').dispatchEvent(new s.w.Event('scroll'));assert.equal(popup.hidden,false);
 button.dispatchEvent(new s.w.KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));assert.equal(popup.hidden,true);button.click();s.key('KeyQ');assert.equal(popup.hidden,true);s.key('KeyQ');button.click();s.click('#xc-code-toggle');assert.equal(popup.hidden,true);
});
test('lazy image URL changes refresh the thumbnail without duplicates',async t=>{
 const s=await setup(t);s.detail();await delay();const {content}=addComment(s,{images:['https://example.com/old.png']});await delay();const original=content.querySelector('img[data-xc-thumb-source]');original.src='https://example.com/new.png';await delay();assert.equal(content.querySelectorAll('.xc-inline-thumbnails').length,1);assert.equal(content.querySelector('.xc-thumbnail img').src,'https://example.com/new.png');
});
test('video thumbnails use their poster rather than the video stream',async t=>{
 const s=await setup(t);s.detail();await delay();const video=s.d.createElement('video');video.src='https://example.com/movie.mp4';video.poster='https://example.com/poster.png';s.d.querySelector('#noteContainer .media-container').append(video);await delay();assert.ok([...s.d.querySelectorAll('.xc-post-thumbnails img')].some(n=>n.src==='https://example.com/poster.png'));assert.equal(s.d.querySelector('.xc-post-thumbnails img[src$="movie.mp4"]'),null);
});
test('avatars and emoji are not converted into image attachments',async t=>{
 const s=await setup(t);s.detail();await delay();const {content}=addComment(s);const emoji=s.d.createElement('img');emoji.className='note-content-emoji';emoji.src='https://example.com/emoji.png';content.append(emoji);await delay();assert.equal(emoji.hasAttribute('data-xc-thumb-source'),false);assert.equal(content.querySelectorAll('.xc-thumbnail').length,0);
});
test('sidebar topics are code-related and never use the real post title',async t=>{
 const s=await setup(t);assert.deepEqual([...s.d.querySelectorAll('#xc-recent a')].map(n=>n.textContent),['优化异步任务调度','重构上下文缓存模块','修复 WebSocket 重连','补充接口单元测试','整理工作区类型定义']);s.native.textContent='不能在侧栏出现的真实帖子标题';await delay();assert.equal(s.d.querySelector('#xc-recent').textContent.includes('不能在侧栏出现'),false);
});
