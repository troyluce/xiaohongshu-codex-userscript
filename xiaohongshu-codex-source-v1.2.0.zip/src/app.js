(() => {
  'use strict';
  const KEY = 'xhs-codex-preferences-v1';
  const CSS = __XC_CSS__;
  const workflow = __XC_WORKFLOW__;
  const sourceFiles = __XC_SOURCE_FILES__;
  const sidebarTopics = ['优化异步任务调度','重构上下文缓存模块','修复 WebSocket 重连','补充接口单元测试','整理工作区类型定义'];
  const html = document.documentElement;
  const icons = {
    codex: '<path d="m8 6-5 6 5 6M16 6l5 6-5 6M14 4l-4 16"/>',
    sidebar: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v9H3Z"/>',
    user: '<circle cx="12" cy="8" r="3"/><path d="M5 21v-3a7 7 0 0 1 14 0v3"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
    eye: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    shield: '<path d="m12 3 8 3v6c0 4-8 9-8 9s-8-5-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
    back: '<path d="m10 5-7 7 7 7M3 12h18"/>',
    external: '<path d="M14 3h7v7m0-7L10 14M10 3H4v17h17v-6"/>',
    sparkle: '<path d="M12 3v18M3 12h18M5.5 5.5l13 13M5.5 18.5l13-13"/>',
    chevron: '<path d="m7 10 5 5 5-5"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    code: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M14 4v16M6 8l3 3-3 3"/>',
    copy: '<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
    branch: '<circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="6" r="2"/><path d="M6 7v10m0-4h6a6 6 0 0 0 6-5"/>'
  };
  const svg = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.folder}</svg>`;
  const reader = (__XC_READER_MODULE__)({ icon:svg, requestUpdate:schedule, canPreview:()=>enabled&&!panic&&!(editorOverlay&&compactEditor.matches) });
  function load() {
    try {
      const raw = typeof GM_getValue === 'function' ? GM_getValue(KEY, {}) : JSON.parse(localStorage.getItem(KEY) || '{}');
      return { enabled: raw.enabled !== false, code: raw.code !== false, theme: ['light','dark','system'].includes(raw.theme) ? raw.theme : 'system' };
    } catch { return { enabled: true, code: true, theme: 'system' }; }
  }
  const prefs = load();
  const system = matchMedia('(prefers-color-scheme: dark)');
  const narrow = matchMedia('(max-width: 1100px)');
  const compactEditor = matchMedia('(max-width: 1000px)');
  let editorOverlay = false;
  let sourceFile = 'workflow.js';
  let codeWrapped = false;
  const flowNodes = new Set();
  const decoratedCards = new WeakMap();
  let collapsed = narrow.matches;
  let enabled = false;
  let panic = false;
  let media = false;
  let detailKey = '';
  let detailNode = null;
  let currentFeed = null;
  const observedFeeds = new WeakSet();
  let shell, restore, queued;
  let priorFocus = null;
  let panicApp = null;
  let appWasInert = false;
  let priorTitle = document.title;
  let addedIcon;
  const originalIcons = new Map();
  const inputAttributes = new Map();
  const introNodes = new Set();
  const iconURL = `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#252627"/><path d="m11 9-6 7 6 7m10-14 6 7-6 7m-3-17-5 20" stroke="#f7f7f8" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>')}`;
  const supported = () => /^\/(?:$|explore(?:\/|$)|search_result(?:\/|$)|user\/profile(?:\/|$)|discovery\/item(?:\/|$))/.test(location.pathname);
  function save() {
    try {
      if (typeof GM_setValue === 'function') GM_setValue(KEY, {...prefs});
      else localStorage.setItem(KEY, JSON.stringify(prefs));
    } catch { /* Appearance still works if preference storage is unavailable. */ }
  }
  function text(id, value) { const e = document.getElementById(id); if (e && e.textContent !== value) e.textContent = value; }
  function pauseMedia() { document.querySelectorAll('#app video, #app audio').forEach(v => { if (!v.paused) v.pause(); }); }
  function theme() {
    html.dataset.xcTheme = prefs.theme === 'system' ? (system.matches ? 'dark' : 'light') : prefs.theme;
    const label = {system:'跟随系统',light:'浅色',dark:'深色'}[prefs.theme];
    text('xc-theme-label', label);
    document.getElementById('xc-theme')?.setAttribute('aria-label', `切换主题，当前${label}`);
  }
  function setBranding(on) {
    if (on) {
      if (document.title !== 'Codex') { priorTitle = document.title; document.title = 'Codex'; }
      const links = [...document.head.querySelectorAll('link[rel~="icon"]')].filter(x => x !== addedIcon);
      for (const link of links) {
        if (!originalIcons.has(link)) originalIcons.set(link, link.getAttribute('href'));
        if (link.getAttribute('href') !== iconURL) link.setAttribute('href', iconURL);
      }
      if (!links.length && !addedIcon) {
        addedIcon = document.createElement('link'); addedIcon.rel = 'icon'; addedIcon.href = iconURL; document.head.append(addedIcon);
      }
    } else {
      if (document.title === 'Codex') document.title = priorTitle;
      for (const [link, href] of originalIcons) {
        if (link.getAttribute('href') === iconURL) {
          if (href === null) link.removeAttribute('href'); else link.setAttribute('href', href);
        }
      }
      originalIcons.clear(); addedIcon?.remove(); addedIcon = null;
    }
  }
  function restoreInput() {
    for (const [input, attributes] of inputAttributes) {
      for (const [name, value] of Object.entries(attributes)) {
        if (value === null) input.removeAttribute(name); else input.setAttribute(name, value);
      }
    }
    inputAttributes.clear();
  }
  function syncNativeInert() {
    const app=document.getElementById('app');
    const needed=enabled && (panic || (editorOverlay && compactEditor.matches));
    if(needed && app) {
      if(panicApp!==app) {
        if(panicApp && !appWasInert) panicApp.removeAttribute('inert');
        panicApp=app; appWasInert=app.hasAttribute('inert');
      }
      app.setAttribute('inert','');
    } else {
      if(panicApp && !appWasInert) panicApp.removeAttribute('inert');
      panicApp=null;
    }
  }
  function setEnabled(value) {
    const was = enabled;
    enabled = value && supported();
    html.dataset.xcEnabled = String(enabled);
    if (!enabled) {
      reader.clear();
      panic = false; editorOverlay=false; syncNativeInert();
      panicApp = null;
      panic = false; media = false; html.dataset.xcPanic = 'false'; applyMedia();
      text('xc-panic-label','隐藏内容');
      document.getElementById('xc-panic-toggle')?.setAttribute('aria-pressed','false');
      document.getElementById('xc-panic-toggle')?.setAttribute('aria-label','隐藏内容');
      html.style.removeProperty('--xc-feed-scroll');
      flowNodes.forEach(n=>n.remove()); flowNodes.clear();
      restoreInput(); introNodes.forEach(n => n.remove()); introNodes.clear();
      setBranding(false);
      if (was && shell?.contains(document.activeElement)) restore?.focus();
    } else {
      theme(); syncEditor(); setBranding(true);
      if (!was) pauseMedia();
      update();
    }
    if (restore) restore.textContent = supported() ? '启用 Codex · Alt+X' : '返回 Codex 工作区';
  }
  function toggle() { prefs.enabled = !enabled; save(); setEnabled(prefs.enabled); }
  function togglePanic() {
    if (!enabled) return;
    reader.closePreview();
    panic = !panic;
    html.dataset.xcPanic = String(panic);
    text('xc-panic-label', panic ? '继续阅读' : '隐藏内容');
    document.getElementById('xc-panic-toggle').setAttribute('aria-pressed', String(panic));
    document.getElementById('xc-panic-toggle').setAttribute('aria-label',panic?'继续阅读':'隐藏内容');
    if (panic) {
      priorFocus = document.activeElement;
      syncNativeInert();
      document.getElementById('xc-panic-toggle').focus();
      text('xc-crumb', '工作区');
      pauseMedia();
    } else {
      syncNativeInert();
      if (priorFocus?.isConnected) priorFocus.focus({preventScroll:true});
      update();
    }
  }
  function closeSidebarOnNarrow() { if (narrow.matches) { collapsed=true; sidebar(); } }
  function search() {
    closeSidebarOnNarrow();
    if (compactEditor.matches && editorOverlay) { editorOverlay=false; syncEditor(); }
    if (panic) togglePanic();
    const input = document.querySelector('#global header input');
    if (detailNode) closeDetail();
    if (input) {
      if (currentFeed) { currentFeed.scrollTop=0; html.style.setProperty('--xc-feed-scroll','0px'); }
      window.scrollTo({top:0,behavior:'instant'}); input.focus();
    }
  }
  function closeDetail() {
    const close = document.querySelector('.note-detail-mask .close-circle .close, .note-detail-mask .close-box');
    if (close) close.click();
    else if (detailNode) location.assign('/explore');
  }
  function buildShell() {
    shell = document.createElement('div'); shell.id = 'xc-shell';
    shell.innerHTML = `
      <nav id="xc-activity-rail" aria-label="活动栏">
        <a class="xc-icon" href="/explore" aria-label="工作区首页">${svg('folder')}</a>
        <button class="xc-icon" id="xc-rail-search" aria-label="搜索任务">${svg('search')}</button>
        <button class="xc-icon" id="xc-rail-code" aria-label="切换源代码面板">${svg('code')}</button>
      </nav>
      <header id="xc-topbar">
        <button class="xc-icon" id="xc-sidebar-toggle" aria-label="切换侧栏" aria-controls="xc-sidebar">${svg('sidebar')}</button>
        <div class="xc-brand">${svg('codex')}<span>Codex</span></div>
        <span class="xc-crumb" id="xc-crumb">工作区</span><span class="xc-spacer"></span>
        <button class="xc-tool" id="xc-back" hidden aria-label="返回任务列表">${svg('back')}<span>返回列表</span></button>
        <button class="xc-tool" id="xc-media" hidden aria-label="查看图片 / 视频" aria-pressed="false">${svg('eye')}<span id="xc-media-label">查看图片 / 视频</span></button>
        <button class="xc-icon" id="xc-code-toggle" aria-label="切换源代码面板" title="显示 / 隐藏源代码" aria-controls="xc-editor">${svg('code')}</button>
        <button class="xc-tool" id="xc-panic-toggle" aria-label="隐藏内容" aria-keyshortcuts="Alt+Q" aria-pressed="false" title="Alt+Q">${svg('shield')}<span id="xc-panic-label">隐藏内容</span></button>
      </header>
      <aside id="xc-sidebar" aria-label="工作区侧栏">
        <button class="xc-nav" id="xc-search">${svg('plus')}<span>新建探索</span></button>
        <button class="xc-nav" id="xc-focus-search">${svg('search')}<span>搜索笔记</span></button>
        <p class="xc-section">项目</p>
        <a class="xc-nav xc-project" id="xc-home" href="/explore">${svg('folder')}<span>个人工作区</span></a>
        <div class="xc-note" id="xc-recent"><span id="xc-recent-empty">最近的任务会显示在这里</span></div>
        <button class="xc-nav" id="xc-profile">${svg('user')}<span>我的主页</span></button>
        <div class="xc-bottom">
          <button class="xc-nav" id="xc-theme">${svg('sun')}<span id="xc-theme-label">跟随系统</span></button>
          <button class="xc-nav" id="xc-original">${svg('external')}<span>原版页面</span><kbd>Alt X</kbd></button>
          <div id="xc-help">Alt Q 隐藏 / 恢复内容</div>
        </div>
      </aside>
      <aside id="xc-editor" aria-label="源代码面板">
        <div id="xc-file-tabs" role="tablist" aria-label="源码文件">
          <button role="tab" aria-selected="true" data-xc-file="workflow.js">workflow.js</button>
          <button role="tab" aria-selected="false" data-xc-file="app.js">app.js</button>
          <button role="tab" aria-selected="false" data-xc-file="reader.js">reader.js</button>
          <button role="tab" aria-selected="false" data-xc-file="style.css">style.css</button>
          <button class="xc-icon" id="xc-editor-close" aria-label="关闭源代码面板">${svg('sidebar')}</button>
        </div>
        <div id="xc-code-crumb"><span>workspace / src / <b id="xc-code-file">workflow.js</b></span><span class="xc-spacer"></span>
          <button id="xc-code-wrap" aria-label="切换代码自动换行" aria-pressed="false">换行</button>
          <button class="xc-icon" id="xc-code-copy" aria-label="复制当前源代码" title="复制源码">${svg('copy')}</button>
        </div>
        <div id="xc-code-body" tabindex="0" role="tabpanel" aria-label="workflow.js 源代码"></div>
        <div id="xc-code-footer"><span id="xc-code-lines"></span><span id="xc-copy-status" role="status">JavaScript · UTF-8</span></div>
      </aside>
      <main id="xc-panic" aria-label="工作区待机画面">
        ${svg('codex')}<h1>工作区已就绪</h1><p>准备开始下一个任务</p>
        <pre><code># Workspace\n\n- Review project structure\n- Organize implementation notes\n- Run checks before committing</code></pre>
      </main>
      <footer id="xc-status"><span>${svg('branch')} main<span id="xc-count"></span></span><span id="xc-media-status">缩略图模式 · 媒体暂停</span></footer>`;
    document.body.append(shell);
    restore = document.createElement('button'); restore.id = 'xc-restore'; restore.type = 'button';
    restore.textContent = '启用 Codex · Alt+X'; document.body.append(restore);
    const on = (id, fn) => document.getElementById(id).addEventListener('click', fn);
    on('xc-sidebar-toggle', () => { collapsed = !collapsed; sidebar(); });
    on('xc-search', search); on('xc-focus-search', search);
    on('xc-panic-toggle', togglePanic);
    on('xc-original', toggle);
    on('xc-restore', () => { if (!supported()) location.assign('/explore'); else toggle(); });
    on('xc-theme', () => { const modes=['system','light','dark']; prefs.theme=modes[(modes.indexOf(prefs.theme)+1)%3]; save(); theme(); });
    on('xc-media', () => { media = !media; applyMedia(); });
    on('xc-back', closeDetail);
    on('xc-profile', () => {
      closeSidebarOnNarrow();
      const link = document.querySelector('#global .side-bar a[href^="/user/profile/"]');
      if (link) link.click(); else document.querySelector('#login-btn')?.click();
    });
    on('xc-code-toggle', toggleEditor); on('xc-rail-code', toggleEditor);
    on('xc-editor-close', toggleEditor); on('xc-rail-search', search);
    document.querySelectorAll('[data-xc-file]').forEach(button=>button.addEventListener('click',()=>renderSource(button.dataset.xcFile)));
    on('xc-code-wrap',()=> {
      codeWrapped=!codeWrapped;
      document.getElementById('xc-code-body').classList.toggle('xc-code-wrapped',codeWrapped);
      document.getElementById('xc-code-wrap').setAttribute('aria-pressed',String(codeWrapped));
    });
    on('xc-code-copy',async()=> {
      try { await copySourceText(sourceFiles[sourceFile]); text('xc-copy-status','已复制'); }
      catch { text('xc-copy-status','请选择代码后复制'); }
    });
    document.getElementById('xc-file-tabs').addEventListener('keydown',e=> {
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key)) return;
      const tabs=[...document.querySelectorAll('[data-xc-file]')];
      const index=tabs.indexOf(document.activeElement);
      if(index<0) return;
      e.preventDefault();
      const next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(index+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
      renderSource(tabs[next].dataset.xcFile); tabs[next].focus();
    });
    renderSource(sourceFile); syncEditor(); sidebar();
  }
  async function copySourceText(value) {
    if(typeof GM_setClipboard==='function') { GM_setClipboard(value,'text'); return; }
    const active=document.activeElement;
    const area=document.createElement('textarea'); area.value=value; area.readOnly=true;
    area.style.cssText='position:fixed;left:-10000px;top:0;width:1px;height:1px';
    shell.append(area); area.focus({preventScroll:true}); area.select();
    let copied=false;
    try { copied=typeof document.execCommand==='function' && document.execCommand('copy'); }
    finally { area.remove(); active?.focus({preventScroll:true}); }
    if(copied) return;
    let timer;
    try {
      await Promise.race([
        navigator.clipboard.writeText(value),
        new Promise((_,reject)=> { timer=setTimeout(()=>reject(new Error('Clipboard unavailable')),2500); }),
      ]);
    } finally { clearTimeout(timer); }
  }
  function syncEditor() {
    const open=compactEditor.matches ? editorOverlay : prefs.code;
    html.dataset.xcEditor=String(open);
    html.dataset.xcEditorOverlay=String(open && compactEditor.matches);
    document.getElementById('xc-code-toggle')?.setAttribute('aria-expanded',String(open));
    document.getElementById('xc-rail-code')?.setAttribute('aria-pressed',String(open));
    document.getElementById('xc-editor')?.setAttribute('aria-hidden',String(!open));
    syncNativeInert();
    if(enabled && open && compactEditor.matches) { reader.closePreview(); pauseMedia(); }
  }
  function toggleEditor() {
    if(compactEditor.matches) { editorOverlay=!editorOverlay; closeSidebarOnNarrow(); }
    else { prefs.code=!prefs.code; save(); }
    syncEditor();
    if(compactEditor.matches && editorOverlay) document.getElementById('xc-code-body')?.focus({preventScroll:true});
    else document.getElementById('xc-code-toggle')?.focus();
  }
  function renderSource(file) {
    if(!Object.hasOwn(sourceFiles,file)) return;
    sourceFile=file;
    const body=document.getElementById('xc-code-body');
    const fragment=document.createDocumentFragment();
    const lines=sourceFiles[file].split('\n');
    lines.forEach((line,index)=> {
      const row=document.createElement('div'); row.className='xc-source-line';
      const number=document.createElement('span'); number.className='xc-line-number'; number.textContent=String(index+1); number.setAttribute('aria-hidden','true');
      const content=document.createElement('span'); content.className='xc-line-code';
      workflow.appendHighlightedLine(content,line,file.endsWith('.css')?'css':'javascript');
      row.append(number,content); fragment.append(row);
    });
    body.replaceChildren(fragment); body.scrollTop=0; body.scrollLeft=0;
    body.setAttribute('aria-label',file+' 源代码');
    document.querySelectorAll('[data-xc-file]').forEach(button=> { const active=button.dataset.xcFile===file; button.setAttribute('aria-selected',String(active)); button.tabIndex=active?0:-1; });
    text('xc-code-file',file); text('xc-code-lines',lines.length+' lines');
    text('xc-copy-status',(file.endsWith('.css')?'CSS':'JavaScript')+' · UTF-8');
  }
  function codeBlock(code,compact=false) {
    const block=document.createElement('pre'); block.className=compact?'xc-flow-code xc-flow-code-small':'xc-flow-code';
    const content=document.createElement('code');
    code.split('\n').forEach((line,index)=> {
      if(index) content.append('\n');
      workflow.appendHighlightedLine(content,line,'javascript');
    });
    block.append(content); return block;
  }
  function agentFlow(full=true,index=0) {
    const wrapper=document.createElement('div'); wrapper.className=full?'xc-intro xc-agent-flow':'xc-agent-step';
    const heading=document.createElement('div'); heading.className='xc-agent-heading';
    heading.innerHTML=svg('codex');
    const label=document.createElement('span'); label.textContent=full?'Agent workflow':'Inspect context'; heading.append(label);
    const description=document.createElement('p'); description.textContent=workflow.describeStep(index);
    wrapper.append(heading,description,codeBlock(full?workflow.workflowCode():workflow.taskCode(index),!full));
    if(full) {
      const summary=document.createElement('div'); summary.className='xc-flow-summary'; summary.textContent='Read context  /  Inspect source  /  Review changes'; wrapper.append(summary);
    }
    return wrapper;
  }
  function decorateTasks(items) {
    for(const [index,card] of items.entries()) {
      const old=decoratedCards.get(card);
      if(old?.isConnected) continue;
      const copied=card.querySelector('.xc-agent-step');
      if(copied) { decoratedCards.set(card,copied); flowNodes.add(copied); continue; }
      const footer=card.querySelector('.footer');
      if(!footer) continue;
      const step=agentFlow(false,index);
      footer.before(step); decoratedCards.set(card,step); flowNodes.add(step);
    }
    for(const node of flowNodes) if(!node.isConnected) flowNodes.delete(node);
  }
  function sidebar() {
    html.dataset.xcCollapsed = String(collapsed);
    document.getElementById('xc-sidebar-toggle')?.setAttribute('aria-expanded',String(!collapsed));
  }
  function applyMedia() {
    html.dataset.xcMedia = media ? 'show' : 'hide';
    text('xc-media-label', media ? '收起图片 / 视频' : '查看图片 / 视频');
    document.getElementById('xc-media')?.setAttribute('aria-pressed',String(media));
    document.getElementById('xc-media')?.setAttribute('aria-label',media?'收起图片 / 视频':'查看图片 / 视频');
    text('xc-media-status', media ? '当前笔记媒体已展开' : '缩略图模式 · 媒体暂停');
    reader.closePreview();
    if (enabled && !media) pauseMedia();
  }
  function update() {
    if (!enabled) return;
    if (!supported()) { setEnabled(false); return; }
    for (const n of introNodes) if (!n.isConnected) introNodes.delete(n);
    for (const [n, attributes] of inputAttributes) if (!n.isConnected) {
      for (const [name,value] of Object.entries(attributes)) { if(value===null)n.removeAttribute(name);else n.setAttribute(name,value); }
      inputAttributes.delete(n);
    }
    const input = document.querySelector('#global header input');
    if (input && !inputAttributes.has(input)) {
      inputAttributes.set(input,{placeholder:input.getAttribute('placeholder'),'aria-label':input.getAttribute('aria-label')});
      input.setAttribute('placeholder','搜索任务内容，按 Enter 查找…'); input.setAttribute('aria-label','搜索小红书笔记');
    }
    const feed = document.querySelector('#global .feeds-page, #global .search-page');
    currentFeed = feed;
    if (feed) {
      html.style.setProperty('--xc-feed-scroll',`${feed.scrollTop}px`);
      if (!observedFeeds.has(feed)) {
        observedFeeds.add(feed);
        feed.addEventListener('scroll',()=> {
          if (enabled && currentFeed===feed) html.style.setProperty('--xc-feed-scroll',`${feed.scrollTop}px`);
        },{passive:true});
      }
    }
    if (feed && !feed.querySelector(':scope > .xc-intro')) {
      const intro=agentFlow(); feed.prepend(intro); introNodes.add(intro);
    }
    const nextNode = document.querySelector('#noteContainer');
    const key = nextNode ? (nextNode.parentElement.getAttribute('note-id') || location.pathname + (nextNode.querySelector('#detail-title')?.textContent || '')) : '';
    if (nextNode !== detailNode || key !== detailKey) {
      detailNode=nextNode; detailKey=key; media=false; applyMedia();
    }
    html.dataset.xcDetail=String(!!nextNode);
    const scroller=nextNode?.querySelector('.note-scroller');
    if(scroller && !scroller.querySelector(':scope>.xc-agent-flow')) {
      const flow=agentFlow(); scroller.prepend(flow); flowNodes.add(flow);
    }
    document.getElementById('xc-back').hidden = !nextNode;
    document.getElementById('xc-media').hidden = !nextNode;
    if (!panic) text('xc-crumb', nextNode ? '任务详情' : location.pathname.startsWith('/search_result') ? '搜索结果' : '工作区');
    const items = workflow.collectTaskCards(document);
    decorateTasks(items);
    reader.update(document.getElementById('app'),{expanded:media});
    text('xc-count', items.length ? ` · ${items.length} 项任务` : '');
    const recent = document.getElementById('xc-recent');
    const links = [...items].slice(0,5).map(n => n.querySelector('a.title')).filter(Boolean);
    const signature = JSON.stringify(links.map(a=>a.getAttribute('href')));
    if (recent.dataset.signature !== signature) {
      recent.dataset.signature=signature; recent.replaceChildren();
      sidebarTopics.forEach((label,index)=> {
        const native=links[index];
        let target='/explore';
        try {
          if(native) {
            const url=new URL(native.getAttribute('href'),location.origin);
            if(url.origin===location.origin && /^\/(explore|search_result|discovery\/item)\//.test(url.pathname)) target=url.href;
          }
        } catch { /* Keep the workspace's normal home route. */ }
        const a=document.createElement('a'); a.href=target; a.textContent=label; a.title=label;
        a.addEventListener('click',event=> {
          if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey||event.button!==0) return;
          if(target!=='/explore' && native?.isConnected) { event.preventDefault(); native.click(); closeSidebarOnNarrow(); }
          else { event.preventDefault(); search(); }
        });
        recent.append(a);
      });
    }
    document.getElementById('xc-home').setAttribute('aria-current',location.pathname==='/explore'?'page':'false');
    setBranding(true);
  }
  function schedule() {
    if (queued) return;
    queued = setTimeout(() => {
      queued=0;
      if (prefs.enabled && !enabled && supported()) setEnabled(true);
      else update();
    },100);
  }
  function boot() {
    if (document.getElementById('xc-shell')) return;
    const style=document.createElement('style'); style.id='xc-style'; style.textContent=CSS; document.head.append(style);
    buildShell(); setEnabled(prefs.enabled); applyMedia();
    document.addEventListener('keydown',e=> {
      if (e.isComposing || e.repeat || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (e.code==='KeyQ' && enabled) { e.preventDefault(); togglePanic(); }
      if (e.code==='KeyX') {
        const editing=e.target instanceof Element && e.target.closest('input,textarea,[contenteditable]:not([contenteditable="false"]),[role="textbox"]');
        if (!editing) { e.preventDefault(); toggle(); }
      }
    },true);
    document.addEventListener('play',e=> {
      if (enabled && (panic || (editorOverlay && compactEditor.matches) || !media || !e.target.closest('#noteContainer'))) e.target.pause?.();
    },true);
    document.addEventListener('click',schedule,true);
    addEventListener('popstate',schedule); addEventListener('hashchange',schedule);
    const observer = new MutationObserver(records=> {
      if (records.some(r=> !(r.target instanceof Element ? r.target : r.target.parentElement)?.closest('#xc-shell,#xc-restore,.xc-intro,.xc-agent-step,[data-xc-reader-owned]'))) schedule();
    });
    observer.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['src','srcset','poster','data-src']});
    new MutationObserver(()=> { if(enabled) { setBranding(true); schedule(); } else if(document.title!=='Codex') priorTitle=document.title; }).observe(document.head,{childList:true,subtree:true,characterData:true});
    system.addEventListener('change',theme);
    narrow.addEventListener('change',()=> { collapsed=narrow.matches; sidebar(); });
    compactEditor.addEventListener('change',()=> { editorOverlay=false; syncEditor(); });
    if (typeof GM_registerMenuCommand==='function') {
      GM_registerMenuCommand('Codex：切换原版 / 伪装 (Alt+X)',toggle);
      GM_registerMenuCommand('Codex：隐藏 / 恢复内容 (Alt+Q)',togglePanic);
      GM_registerMenuCommand('Codex：切换深浅主题',()=>document.getElementById('xc-theme').click());
    }
  }
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
})();
