function createWorkspaceWorkflow() {
  'use strict';

  const selectors = Object.freeze({
    tasks: '#global .feeds-container .note-item',
    title: 'a.title',
    author: '.author .name',
    detail: '#noteContainer',
    description: '#detail-desc',
  });

  const states = Object.freeze({
    ready: 'ready',
    inspecting: 'inspecting',
    reading: 'reading',
    waiting: 'waiting',
  });

  function normalizeText(value, limit = 240) {
    return String(value || '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, limit);
  }

  function collectTaskCards(root = document) {
    return [...root.querySelectorAll(selectors.tasks)]
      .filter(card => !card.hidden);
  }

  function readTask(card, index = 0) {
    const title = card.querySelector(selectors.title);
    return {
      id: card.getAttribute('data-note-id') || `task-${index}`,
      index,
      title: normalizeText(title?.textContent),
      author: normalizeText(card.querySelector(selectors.author)?.textContent),
      href: title?.getAttribute('href') || '',
      node: card,
    };
  }

  function inspectWorkspace(root = document) {
    const cards = collectTaskCards(root);
    const detail = root.querySelector(selectors.detail);
    return {
      state: detail ? states.reading : states.ready,
      taskCount: cards.length,
      activeTitle: normalizeText(detail?.querySelector('#detail-title')?.textContent),
      tasks: cards.map(readTask),
      mediaPolicy: 'thumbnail-until-requested',
    };
  }

  function createPlan(context) {
    return [
      { id: 'context', label: 'Read workspace context', status: states.ready },
      { id: 'inspect', label: 'Inspect incoming tasks', status: states.inspecting },
      { id: 'open', label: 'Open the selected task', status: context.state },
      { id: 'review', label: 'Review source and continue', status: states.waiting },
    ];
  }

  function workflowCode() {
    return [
      'async function runAgent(workspace) {',
      '  const context = await workspace.readContext();',
      '  const plan = agent.createPlan(context);',
      '',
      '  for await (const step of agent.run(plan)) {',
      '    const result = await tools.inspect(step);',
      '    await workspace.apply(result);',
      '    await checks.verify(result.scope);',
      '  }',
      '',
      '  return agent.summarize(workspace.changes);',
      '}',
    ].join('\n');
  }

  function taskCode(index = 0) {
    const steps = [
      ['const context = await agent.readContext();', 'const task = context.tasks.next();'],
      ['const plan = await agent.plan(task);', 'await tools.inspect(plan.files);'],
      ['const result = await reader.open(task);', 'await workspace.attach(result);'],
      ['await agent.review(workspace.changes);', 'return workspace.nextTask();'],
    ];
    return steps[index % steps.length].join('\n');
  }

  function describeStep(index = 0) {
    const descriptions = [
      'I’ll read the context first, then inspect the relevant details.',
      'The next step is to check the source and keep the change focused.',
      'I’m tracing the data flow before choosing the implementation.',
      'I’ll review the result and keep the original behavior intact.',
    ];
    return descriptions[index % descriptions.length];
  }

  function tokenize(line, language = 'javascript') {
    const tokens = [];
    const pattern = /\/\/.*$|\/\*.*?(?:\*\/|$)|'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`(?:\\.|[^`\\])*`|\b(?:async|await|const|let|function|return|if|else|for|while|try|catch|throw|new|class|typeof|instanceof|true|false|null|undefined|import|export|from|of|in)\b|\b\d+(?:\.\d+)?\b|--[a-zA-Z][\w-]*/g;
    let start = 0;
    for (const match of line.matchAll(pattern)) {
      if (match.index > start) tokens.push({ text: line.slice(start, match.index), kind: '' });
      const value = match[0];
      let kind = 'keyword';
      if (value.startsWith('//') || value.startsWith('/*')) kind = 'comment';
      else if (/^['"`]/.test(value)) kind = 'string';
      else if (/^\d/.test(value)) kind = 'number';
      else if (language === 'css' && value.startsWith('--')) kind = 'property';
      tokens.push({ text: value, kind });
      start = match.index + value.length;
    }
    if (start < line.length) tokens.push({ text: line.slice(start), kind: '' });
    return tokens;
  }

  function appendHighlightedLine(parent, line, language) {
    for (const token of tokenize(line, language)) {
      const span = document.createElement('span');
      if (token.kind) span.className = `xc-token-${token.kind}`;
      span.textContent = token.text;
      parent.append(span);
    }
  }

  return Object.freeze({
    collectTaskCards,
    readTask,
    inspectWorkspace,
    createPlan,
    workflowCode,
    taskCode,
    describeStep,
    appendHighlightedLine,
  });
}
