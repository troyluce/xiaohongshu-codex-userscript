function createReadingPresentation({ icon, requestUpdate, canPreview }) {
  const owned = '[data-xc-reader-owned]';
  const commentBlocks = new Map();
  const groups = new Map();
  const markedImages = new Set();
  let popup, previewImage, previewCaption, trigger, pinned = false, closeTimer, suppressFocus = false;
  const phrases = [
    ['First I’ll inspect the context and trace the relevant data flow.', 'The important detail is how the state changes between these steps.', 'Keep the change focused, then review the result against the original behavior.'],
    ['Start with the surrounding context before choosing an implementation.', 'Check the ordering: cleanup should happen after the pending work is complete.', 'A small, targeted change makes the next verification easier to follow.'],
    ['I’m following the execution path and checking the assumptions at each boundary.', 'Compare the inputs with the current state, then inspect the affected branch.', 'That leaves one clear next step: verify the result and keep the existing contract.'],
    ['Read the relevant context first, then look for the smallest useful change.', 'The retry path and the normal path should agree on the same state transition.', 'Review the edge case once more before moving on to the next task.'],
  ];
  function own(node) { node.setAttribute('data-xc-reader-owned', ''); return node; }
  function hash(value) { let n=2166136261; for(const c of value) n=Math.imul(n^c.charCodeAt(0),16777619); return n>>>0; }
  function commentContent(comment) {
    return [...comment.querySelectorAll('.content,.comment-content')].find(n=>n.closest('.comment-item')===comment);
  }
  function decorateComments(root) {
    root.querySelectorAll('.comment-item').forEach((comment,index)=> {
      const content=commentContent(comment);
      if(!content) return;
      const key=comment.id || `${index}:${content.textContent}`;
      const record=commentBlocks.get(comment);
      if(record?.block.isConnected && record.content===content && record.key===key) return;
      record?.block.remove();
      [...comment.querySelectorAll('.xc-comment-workflow')].filter(n=>n.closest('.comment-item')===comment).forEach(n=>n.remove());
      const seed=hash(key), seconds=3+(seed%27);
      const block=own(document.createElement('details')); block.className='xc-comment-workflow'; block.open=true;
      const summary=document.createElement('summary'); summary.innerHTML=icon('sparkle');
      const label=document.createElement('span'); label.textContent=`Worked for ${seconds}s`; summary.append(label);
      const chevron=document.createElement('span'); chevron.className='xc-work-chevron'; chevron.innerHTML=icon('chevron'); summary.append(chevron);
      const process=document.createElement('div'); process.className='xc-comment-process';
      for(const line of phrases[seed%phrases.length]) { const p=document.createElement('p'); p.textContent=line; process.append(p); }
      block.append(summary,process); content.before(block);
      commentBlocks.set(comment,{block,content,key});
    });
    for(const [comment,record] of commentBlocks) if(!comment.isConnected) { record.block.remove(); commentBlocks.delete(comment); }
  }
  function mediaURL(value) {
    if(!value) return '';
    try {
      const url=new URL(value,location.href);
      if(['https:','http:','blob:'].includes(url.protocol)) return url.href;
      if(url.protocol==='data:' && /^data:image\/(?:png|jpe?g|webp|gif|avif|svg\+xml)[;,]/i.test(value)) return value;
    } catch { /* An incomplete lazy image is picked up on its next update. */ }
    return '';
  }
  function imageSource(node,type='image') {
    const src=mediaURL(node.tagName==='VIDEO' ? node.getAttribute('poster') : (node.currentSrc || node.getAttribute('src') || node.getAttribute('data-src')));
    return src ? {src,type,width:node.naturalWidth||Number(node.getAttribute('width'))||0,height:node.naturalHeight||Number(node.getAttribute('height'))||0} : null;
  }
  function sourcesIn(container) {
    if(!container) return [];
    const result=[],seen=new Set();
    container.querySelectorAll('img,video[poster]').forEach(node=> {
      if(node.closest(owned)) return;
      const item=imageSource(node,node.tagName==='VIDEO'?'video':'image');
      if(item && !seen.has(item.src)) { seen.add(item.src); result.push(item); }
    });
    return result;
  }
  function dimensions(item) { return item.width && item.height ? `${item.width}×${item.height}` : '悬停放大'; }
  function createPopup() {
    if(popup?.isConnected) return;
    popup=own(document.createElement('div')); popup.id='xc-image-preview'; popup.hidden=true; popup.setAttribute('role','dialog'); popup.setAttribute('aria-label','图片预览');
    const close=document.createElement('button'); close.type='button'; close.className='xc-preview-close'; close.setAttribute('aria-label','关闭图片预览'); close.innerHTML=icon('close');
    close.addEventListener('click',()=>closePreview(true));
    previewImage=document.createElement('img'); previewImage.alt='放大的图片预览'; previewImage.decoding='async';
    previewCaption=document.createElement('div'); previewCaption.className='xc-preview-caption';
    popup.append(close,previewImage,previewCaption);
    popup.addEventListener('mouseenter',()=>clearTimeout(closeTimer));
    popup.addEventListener('mouseleave',()=> { if(!pinned) deferClose(); });
    document.getElementById('xc-shell').append(popup);
  }
  function positionPreview(button) {
    const box=button.getBoundingClientRect();
    const width=Math.min(900,innerWidth-32), maxHeight=Math.max(120,Math.min(650,innerHeight-96));
    const left=Math.max(16,Math.min(box.left,innerWidth-width-16));
    let top=box.bottom+8;
    if(top+maxHeight>innerHeight-16) top=Math.max(56,box.top-maxHeight-8);
    popup.style.left=`${left}px`; popup.style.top=`${Math.max(56,top)}px`; popup.style.width=`${width}px`;
    popup.style.maxHeight=`${maxHeight}px`;
    previewImage.style.maxHeight=`${Math.max(100,maxHeight-38)}px`;
  }
  function openPreview(button,item,lock=false) {
    if(!canPreview()) return;
    clearTimeout(closeTimer); createPopup();
    if(trigger && trigger!==button) trigger.setAttribute('aria-expanded','false');
    pinned=lock || (trigger===button && pinned); trigger=button;
    previewImage.src=item.src;
    previewCaption.textContent=`${item.type==='video'?'Video poster':'Image'} · ${dimensions(item)}`;
    previewImage.onload=()=> {
      if(previewImage.naturalWidth) previewCaption.textContent=`${item.type==='video'?'Video poster':'Image'} · ${previewImage.naturalWidth}×${previewImage.naturalHeight}`;
    };
    previewImage.onerror=()=> { previewCaption.textContent='图片暂不可用，可使用右上角查看图片 / 视频'; };
    popup.hidden=false; button.setAttribute('aria-expanded','true');
    positionPreview(button);
  }
  function closePreview(focus=false) {
    clearTimeout(closeTimer);
    if(popup) { popup.hidden=true; previewImage?.removeAttribute('src'); }
    const previous=trigger; trigger=null; pinned=false;
    previous?.setAttribute('aria-expanded','false');
    if(focus && previous?.isConnected && canPreview()) {
      suppressFocus=true;
      try { previous.focus({preventScroll:true}); } finally { suppressFocus=false; }
    }
  }
  function deferClose() { clearTimeout(closeTimer); closeTimer=setTimeout(()=> { if(!pinned) closePreview(); },120); }
  function thumbnail(item,index) {
    const button=document.createElement('button'); button.type='button'; button.className='xc-thumbnail';
    button.setAttribute('aria-label',`${item.type==='video'?'视频封面':'图片'} ${index+1}，悬停或点击放大`);
    button.setAttribute('aria-expanded','false'); button.setAttribute('aria-haspopup','dialog');
    const img=document.createElement('img'); img.src=item.src; img.alt=item.type==='video'?'视频封面缩略图':'图片缩略图'; img.loading='lazy'; img.decoding='async';
    const caption=document.createElement('span'); caption.className='xc-thumbnail-caption';
    caption.textContent=`${item.type==='video'?'Video':'Image'} · ${dimensions(item)}`;
    img.addEventListener('load',()=> { item.width=img.naturalWidth||item.width; item.height=img.naturalHeight||item.height; caption.textContent=`${item.type==='video'?'Video':'Image'} · ${dimensions(item)}`; });
    img.addEventListener('error',()=> { caption.textContent='图片暂不可用'; button.classList.add('xc-thumbnail-error'); });
    button.append(img,caption);
    button.addEventListener('mouseenter',()=>openPreview(button,item));
    button.addEventListener('mouseleave',()=> { if(!pinned) deferClose(); });
    button.addEventListener('focus',()=> { if(!suppressFocus) openPreview(button,item); });
    button.addEventListener('blur',()=> { if(!pinned) closePreview(); });
    button.addEventListener('click',event=> { event.preventDefault(); event.stopPropagation(); openPreview(button,item,true); });
    return button;
  }
  function group(owner,anchor,items,kind='post') {
    const signature=JSON.stringify(items.map(item=>[item.src,item.type]));
    let record=groups.get(owner);
    if(record && record.signature===signature && record.node.isConnected && record.anchor===anchor) return;
    if(record?.node.contains(trigger)) closePreview();
    record?.node.remove();
    // Cloned native cards can carry old DOM decorations but not their handlers.
    if(!record) { const copied=anchor.nextElementSibling; if(copied?.matches('.xc-media-thumbnails') && copied.dataset.xcGroupKind===kind) copied.remove(); }
    if(!items.length) { groups.delete(owner); return; }
    const node=own(document.createElement('div')); node.className=`xc-media-thumbnails xc-${kind}-thumbnails`; node.dataset.xcGroupKind=kind;
    node.setAttribute('aria-label',kind==='post'?'笔记图片缩略图':'图片缩略图');
    items.forEach((item,index)=>node.append(thumbnail(item,index)));
    anchor.after(node); groups.set(owner,{node,signature,anchor});
  }
  function ignoreInlineImage(image) {
    return image.closest(`${owned},.avatar,.avatar-container,.author,.author-container,.emoji,.emoticon`) || /avatar|emoji|emoticon/i.test(image.className);
  }
  function update(root,{expanded=false}={}) {
    if(!root) { closePreview(); return; }
    if(trigger && (!trigger.isConnected || !canPreview())) closePreview();
    decorateComments(root);
    root.querySelectorAll('.note-item').forEach(card=> {
      const title=card.querySelector('a.title');
      if(title) group(card,title,sourcesIn(card.querySelector('.cover')),'feed');
    });
    const note=root.querySelector('#noteContainer');
    if(note) {
      const anchor=note.querySelector('#detail-title') || note.querySelector('#detail-desc');
      if(anchor) group(note,anchor,sourcesIn(note.querySelector(':scope > .media-container')),'post');
      note.querySelectorAll('.note-content img,.comment-item img').forEach(image=> {
        if(ignoreInlineImage(image)) return;
        const item=imageSource(image);
        if(!item) { groups.get(image)?.node.remove(); groups.delete(image); image.removeAttribute('data-xc-thumb-source'); markedImages.delete(image); return; }
        image.setAttribute('data-xc-thumb-source',''); markedImages.add(image);
        group(image,image,[item],'inline');
      });
    }
    for(const [owner,record] of groups) if(!owner.isConnected) { if(record.node.contains(trigger)) closePreview(); record.node.remove(); groups.delete(owner); }
    for(const image of markedImages) if(!image.isConnected) markedImages.delete(image);
    if(expanded) closePreview();
  }
  function clear() {
    closePreview();
    document.querySelectorAll(owned).forEach(node=>node.remove());
    document.querySelectorAll('[data-xc-thumb-source]').forEach(node=>node.removeAttribute('data-xc-thumb-source'));
    commentBlocks.clear(); groups.clear(); markedImages.clear(); popup=null; previewImage=null;
  }
  document.addEventListener('keydown',event=> {
    if(event.key==='Escape' && popup && !popup.hidden) { event.preventDefault(); event.stopImmediatePropagation(); closePreview(true); }
  },true);
  document.addEventListener('scroll',()=> { if(popup && !popup.hidden && !pinned) closePreview(); },{capture:true,passive:true});
  addEventListener('resize',()=>closePreview());
  document.addEventListener('load',event=> {
    if(event.target instanceof HTMLImageElement && event.target.closest('#app') && !event.target.closest(owned) && canPreview()) requestUpdate();
  },true);
  return {update,clear,closePreview};
}
